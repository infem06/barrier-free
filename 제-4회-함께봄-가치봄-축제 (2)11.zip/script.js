document.addEventListener('DOMContentLoaded', () => {
    // Internationalization Data
    const translations = {
        ko: {
            festival_name: "제4회 무장애마을축제 - 함께봄 가치봄",
            logo_line1: "누구도 배제되지 않는",
            logo_line2: "무장애마을 축제",
            nav_home: "홈",
            nav_programs: "체험부스",
            nav_performance: "공연시간표",
            nav_parking: "주차안내",
            nav_accessibility: "이동편의",
            nav_inquiry: "문의/의견",
            hero_subtitle_top: "제4회 무장애마을축제",
            hero_title: "함께봄 가치봄",
            hero_date: "2026. 04. 25(토) 11:00 ~ 16:00",
            hero_venue: "정왕동 미관광장3호",
            hero_btn_map: "행사장소확인하기",
            hero_btn_booths: "체험부스 안내",
            hero_btn_performance: "공연시간표",
            about_tag: "ABOUT",
            about_title: "함께 보고 가치를 나누는 축제",
            about_item1_title: "함께봄 :",
            about_item1_desc: "장애 비장애가 함께 보는 행복한 축제",
            about_item2_title: "가치봄 :",
            about_item2_desc: "다양성의 가치를 보는 사회",
            about_main_desc: "본 축제는 장애인과 비장애인이 함께 어우러져 소통하는 축제의 장을 마련하고, 장애인식개선 체험을 통한 사회적 인식 개선을 목적으로 하며 장애인 권리 증진을 도모하기 위해 진행되는 행사입니다.",
            image_caption: "<2024년 제2회 함께봄 가치봄 축제>",
            experience_tag: "EXPERIENCE",
            experience_title: "체험부스 안내",
            booth1_title: "운영본부 및 안내소",
            booth1_desc: "축제 안내 및 미아 보호, 분실물 접수",
            booth2_title: "기념품 수령 및 경품 응모",
            booth2_desc: "스탬프 투어 완료 후 기념품 수령",
            booth3_title: "점자 명함 만들기 체험",
            booth3_desc: "자신의 이름을 점자로 직접 찍어보는 체험",
            booth4_title: "휠체어 면허 따기",
            booth4_desc: "수동 휠체어 조작법 배우기 및 장애물 통과",
            booth5_title: "흰지팡이 보행 체험",
            booth5_desc: "안대를 착용하고 흰지팡이로 보행로 이동하기",
            booth6_title: "수어 기초 및 인사 배우기",
            booth6_desc: "간단한 수어 단어와 인사말 배우기",
            booth7_title: "배리어프리 영화 홍보",
            booth7_desc: "화면 해설 및 자막 영화 제작 과정 안내",
            booth8_title: "장애인 보조기기 전시",
            booth8_desc: "최신 정보통신 보조기기 및 생활 보조기구 체험",
            booth9_title: "장애인 스포츠 체험 (보치아)",
            booth9_desc: "패럴림픽 정식 종목인 보치아 경기 체험",
            booth10_title: "장애인 스포츠 체험 (농구)",
            booth10_desc: "휠체어 농구 슛 체험 및 경기 규칙 안내",
            booth11_title: "장애인 생산품 '꿈드래' 마켓",
            booth11_desc: "중증장애인 생산품 전시 및 판매",
            booth12_title: "장애인 일자리 상담",
            booth12_desc: "장애인 취업 지원 및 직업 훈련 프로그램 안내",
            booth13_title: "발달장애인 아티스트 전시",
            booth13_desc: "발달장애인 작가들의 독창적인 미술 작품 감상",
            booth14_title: "장애인 권익 옹호 상담",
            booth14_desc: "장애인 인권 침해 예방 및 법률 상담 지원",
            booth15_title: "장애 인식 개선 OX 퀴즈",
            booth15_desc: "장애에 대한 올바른 상식을 퀴즈로 풀기",
            booth16_title: "수어 노래 배우기",
            booth16_desc: "아름다운 노래 가사를 수어로 표현해보기",
            booth17_title: "점자 도서 및 촉각 체험",
            booth17_desc: "점자 도서 읽기 및 촉각 교구 체험",
            booth18_title: "장애인 가족 지원 안내",
            booth18_desc: "장애인 가족을 위한 휴식 및 상담 프로그램 안내",
            booth19_title: "장애인 활동 지원 상담",
            booth19_desc: "활동 지원 서비스 신청 및 이용 방법 안내",
            booth20_title: "장애인 복지 혜택 안내",
            booth20_desc: "장애인 연금, 수당 및 각종 감면 혜택 정보",
            booth21_title: "보조 기기 수리 센터",
            booth21_desc: "휠체어 및 보조기기 무상 점검 및 수리",
            booth22_title: "장애인 문화 예술 (도예)",
            booth22_desc: "손끝으로 빚는 도자기 만들기 체험",
            booth23_title: "장애인 문화 예술 (원예)",
            booth23_desc: "꽃과 식물을 활용한 힐링 원예 체험",
            booth24_title: "장애인 정보화 교육 안내",
            booth24_desc: "스마트폰 및 PC 활용 교육 프로그램 소개",
            booth25_title: "장애인 인권 영화제 홍보",
            booth25_desc: "장애인 인권 영화 상영 일정 및 참여 안내",
            booth26_title: "장애인 자립 생활 안내",
            booth26_desc: "자립 생활 주택 및 자립 지원 서비스 소개",
            booth27_title: "편의시설 모니터링 홍보",
            booth27_desc: "무장애 도시를 위한 편의시설 점검 활동 안내",
            booth28_title: "장애인 평생 교육 안내",
            booth28_desc: "성인 장애인을 위한 평생 학습 프로그램 소개",
            booth29_title: "장애인 체육회 홍보",
            booth29_desc: "지역 장애인 체육 동호회 및 가입 안내",
            booth30_title: "만족도 조사 및 의견함",
            booth30_desc: "축제 참여 소감 및 개선 의견 남기기",
            performance_tag: "PERFORMANCE",
            performance_title: "공연 시간표",
            performance_tab: "4.25(토)",
            scroll_hint: "옆으로 밀어보기",
            scroll_hint_text: "좌우 스크롤",
            perf_table_time: "시간",
            perf_table_title: "공연명",
            perf_table_artist: "출연진",
            parking_tag: "PARKING",
            parking_title: "주차 안내",
            parking_card1_title: "인근 주차장",
            parking_loc1: "1. 미관광장",
            parking_loc2: "2. 시흥시남부노인복지관",
            parking_loc3: "3. 상생파킹몰",
            parking_btn_map: "장소확인",
            parking_notice: "행사 당일 혼잡이 예상되오니 대중교통 이용을 권장합니다.",
            parking_card2_title: "대중교통 안내",
            parking_bus_info: "정왕역 4호선 또는 인근 이마트 버스정류장에서 하차 후 도보 이동",
            parking_bus_sub: "정왕동 미관광장3호로 오시면 됩니다.",
            accessibility_tag: "ACCESSIBILITY",
            accessibility_title: "이동편의 서비스",
            accessibility_notice: "미관광장의 이동편의 탑승 장소는 정류장에 휠체어 모양이 그려진 곳에서 탑승해야 하며, 출발 시간보다 10분 전에 도착해 있어야 합니다.",
            acc_table_round: "회차",
            acc_table_loc1: "미관광장3호 (행사장)",
            acc_table_loc2: "장현 19단지 정문",
            acc_table_loc3: "목감 7단지 정문",
            acc_table_loc4: "능곡초교 맞은편",
            acc_table_loc5: "시흥시청 정문 맞은편",
            acc_table_loc6: "미관광장3호 (행사장)",
            inquiry_tag: "INQUIRY/FEEDBACK",
            inquiry_title: "문의 및 의견",
            inquiry_form_title: "문의 및 행사 의견 보내기",
            inquiry_label_name: "성함",
            inquiry_placeholder_name: "성함을 입력하세요",
            inquiry_label_email: "연락처/이메일",
            inquiry_placeholder_email: "답변받으실 연락처를 입력하세요",
            inquiry_label_message: "문의 및 의견 내용",
            inquiry_placeholder_message: "문의하실 내용이나 행사에 대한 의견을 입력하세요",
            inquiry_btn_submit: "의견 보내기",
            success_title: "제출완료",
            success_message: "소중한 의견 감사합니다.",
            footer_host_label: "주최 :",
            footer_host_name: "시흥장애인종합복지관",
            footer_organizer_label: "주관 :",
            footer_organizer_name: "시흥장애인종합복지관, 함현상생종합사회복지관, 시흥시평생학습동아리연합회, 시흥시대야종합사회복지관, 시흥시정왕종합사회복지관, 시흥시장애인가족지원센터, 시흥시남부노인복지관",
            footer_contact_label: "문의 :",
            sending: "보내는 중...",
            submit_error: "제출 중 오류가 발생했습니다. 다시 시도해주세요.",
            network_error: "네트워크 오류가 발생했습니다."
        },
        en: {
            festival_name: "Barrier Free Festival - Together See, Value See",
            logo_line1: "No One Excluded",
            logo_line2: "Barrier Free Festival",
            nav_home: "Home",
            nav_programs: "Booths",
            nav_performance: "Performance",
            nav_parking: "Parking",
            nav_accessibility: "Transport Bus",
            nav_inquiry: "Inquiry/Feedback",
            hero_subtitle_top: "The 4th Barrier Free Festival",
            hero_title: "Barrier Free Festival",
            hero_date: "2026. 04. 25(Sat) 11:00 ~ 16:00",
            hero_venue: "Jeongwang-dong Migwan Square No.3",
            hero_btn_map: "Check Location",
            hero_btn_booths: "Booth Guide",
            hero_btn_performance: "Performance Schedule",
            about_tag: "ABOUT",
            about_title: "A Festival to See Together and Share Values",
            about_item1_title: "Together See:",
            about_item1_desc: "A happy festival for both disabled and non-disabled people",
            about_item2_title: "Value See:",
            about_item2_desc: "A society that sees the value of diversity",
            about_main_desc: "This festival aims to provide a place for communication between disabled and non-disabled people, improve social awareness through disability awareness experiences, and promote the rights of disabled people.",
            image_caption: "<2024 The 2nd Together See, Value See Festival>",
            experience_tag: "EXPERIENCE",
            experience_title: "Booth Information",
            booth1_title: "Headquarters & Information",
            booth1_desc: "Festival guidance, child protection, lost and found",
            booth2_title: "Souvenirs & Lucky Draw",
            booth2_desc: "Receive souvenirs after completing stamp tour",
            booth3_title: "Braille Business Card Making",
            booth3_desc: "Experience printing your name in Braille",
            booth4_title: "Wheelchair License",
            booth4_desc: "Learn manual wheelchair operation and pass obstacles",
            booth5_title: "White Cane Walking Experience",
            booth5_desc: "Walking with a white cane while wearing a blindfold",
            booth6_title: "Basic Sign Language",
            booth6_desc: "Learn simple sign language words and greetings",
            booth7_title: "Barrier-free Movie Promotion",
            booth7_desc: "Introduction to audio description and subtitled movies",
            booth8_title: "Assistive Devices Exhibition",
            booth8_desc: "Experience latest ICT and daily assistive devices",
            booth9_title: "Disabled Sports (Boccia)",
            booth9_desc: "Experience Boccia, an official Paralympic sport",
            booth10_title: "Disabled Sports (Basketball)",
            booth10_desc: "Wheelchair basketball shooting and rule guide",
            booth11_title: "Disabled Products 'Dreamdra' Market",
            booth11_desc: "Exhibition and sale of products by severely disabled",
            booth12_title: "Disabled Job Counseling",
            booth12_desc: "Employment support and vocational training guide",
            booth13_title: "Developmental Disabled Artist Exhibition",
            booth13_desc: "Appreciate unique artworks by developmental disabled artists",
            booth14_title: "Disabled Rights Advocacy",
            booth14_desc: "Human rights violation prevention and legal counseling",
            booth15_title: "Disability Awareness OX Quiz",
            booth15_desc: "Solve quizzes about correct common sense on disability",
            booth16_title: "Sign Language Song Learning",
            booth16_desc: "Express beautiful song lyrics in sign language",
            booth17_title: "Braille Books & Tactile Experience",
            booth17_desc: "Read Braille books and experience tactile materials",
            booth18_title: "Disabled Family Support",
            booth18_desc: "Rest and counseling programs for disabled families",
            booth19_title: "Disabled Activity Support Counseling",
            booth19_desc: "Application and usage guide for activity support services",
            booth20_title: "Disabled Welfare Benefits",
            booth20_desc: "Information on pensions, allowances, and various discounts",
            booth21_title: "Assistive Device Repair Center",
            booth21_desc: "Free inspection and repair of wheelchairs and devices",
            booth22_title: "Disabled Culture & Art (Pottery)",
            booth22_desc: "Experience making pottery with fingertips",
            booth23_title: "Disabled Culture & Art (Gardening)",
            booth23_desc: "Healing gardening experience with flowers and plants",
            booth24_title: "Disabled ICT Education Guide",
            booth24_desc: "Introduction to smartphone and PC utilization programs",
            booth25_title: "Disabled Human Rights Film Festival",
            booth25_desc: "Screening schedule and participation guide",
            booth26_title: "Disabled Independent Living Guide",
            booth26_desc: "Introduction to independent living housing and support",
            booth27_title: "Facility Monitoring Promotion",
            booth27_desc: "Facility inspection activities for a barrier-free city",
            booth28_title: "Disabled Lifelong Education",
            booth28_desc: "Lifelong learning programs for disabled adults",
            booth29_title: "Disabled Sports Association",
            booth29_desc: "Local disabled sports clubs and membership guide",
            booth30_title: "Satisfaction Survey & Feedback",
            booth30_desc: "Leave participation impressions and improvement ideas",
            performance_tag: "PERFORMANCE",
            performance_title: "Performance Schedule",
            performance_tab: "Apr 25(Sat)",
            scroll_hint: "Swipe to see more",
            scroll_hint_text: "Scroll Left/Right",
            perf_table_time: "Time",
            perf_table_title: "Performance",
            perf_table_artist: "Artist",
            parking_tag: "PARKING",
            parking_title: "Parking Guide",
            parking_card1_title: "Nearby Parking",
            parking_loc1: "1. Migwan Square",
            parking_loc2: "2. Siheung Southern Welfare Center",
            parking_loc3: "3. Sangsaeng Parking Mall",
            parking_btn_map: "Check Map",
            parking_notice: "Heavy traffic is expected. Public transportation is recommended.",
            parking_card2_title: "Public Transport",
            parking_bus_info: "Get off at Jeongwang Station (Line 4) or nearby E-Mart bus stop",
            parking_bus_sub: "Come to Jeongwang-dong Migwan Square No.3.",
            accessibility_tag: "TRANSPORT BUS",
            accessibility_title: "Transport Bus Services",
            accessibility_notice: "The boarding point for Transport Bus in Migwan Square is marked with a wheelchair icon. Please arrive 10 minutes before departure.",
            acc_table_round: "No.",
            acc_table_loc1: "Migwan Square (Venue)",
            acc_table_loc2: "Janghyeon 19th Complex",
            acc_table_loc3: "Mokgam 7th Complex",
            acc_table_loc4: "Opposite Neunggok ES",
            acc_table_loc5: "Opposite Siheung City Hall",
            acc_table_loc6: "Migwan Square (Venue)",
            inquiry_tag: "INQUIRY/FEEDBACK",
            inquiry_title: "Inquiry & Feedback",
            inquiry_form_title: "Send Inquiry or Feedback",
            inquiry_label_name: "Name",
            inquiry_placeholder_name: "Enter your name",
            inquiry_label_email: "Contact/Email",
            inquiry_placeholder_email: "Enter your contact info",
            inquiry_label_message: "Message",
            inquiry_placeholder_message: "Enter your inquiry or feedback",
            inquiry_btn_submit: "Send Feedback",
            success_title: "Submitted",
            success_message: "Thank you for your valuable feedback.",
            footer_host_label: "Host:",
            footer_host_name: "Siheung Welfare Center for the Disabled",
            footer_organizer_label: "Organizer:",
            footer_organizer_name: "Siheung Welfare Center for the Disabled, Hamhyeon Sangsaeng Welfare Center, Siheung Lifelong Learning Club Association, Siheung Daeya Welfare Center, Siheung Jeongwang Welfare Center, Siheung Disabled Family Support Center, Siheung Southern Welfare Center",
            footer_contact_label: "Inquiry:",
            sending: "Sending...",
            submit_error: "An error occurred during submission. Please try again.",
            network_error: "A network error occurred."
        },
        zh: {
            festival_name: "第四届无障碍村庄庆典 - 共见 价值见",
            logo_line1: "不让任何人掉队",
            logo_line2: "无障碍村庄庆典",
            nav_home: "首页",
            nav_programs: "体验展位",
            nav_performance: "演出时间表",
            nav_parking: "停车指南",
            nav_accessibility: "移动便利",
            nav_inquiry: "咨询/意见",
            hero_subtitle_top: "第四届无障碍村庄庆典",
            hero_title: "无障碍村庄庆典",
            hero_date: "2026. 04. 25(周六) 11:00 ~ 16:00",
            hero_venue: "正往洞 美观广场3号",
            hero_btn_map: "确认活动地点",
            hero_btn_booths: "体验展位指南",
            hero_btn_performance: "演出时间表",
            about_tag: "关于",
            about_title: "共同观看并分享价值的庆典",
            about_item1_title: "共见：",
            about_item1_desc: "残疾人与非残疾人共同观看的幸福庆典",
            about_item2_title: "价值见：",
            about_item2_desc: "看到多样性价值的社会",
            about_main_desc: "本次庆典旨在为残疾人与非残疾人提供交流平台，通过残疾意识改善体验来提高社会认知，并促进残疾人权利的提升。",
            image_caption: "<2024年第二届共见价值见庆典>",
            experience_tag: "体验",
            experience_title: "体验展位指南",
            booth1_title: "运营总部及问讯处",
            booth1_desc: "庆典指南、儿童保护、失物招领",
            booth2_title: "领取纪念品及抽奖",
            booth2_desc: "完成盖章之旅后领取纪念品",
            booth3_title: "制作盲文名片体验",
            booth3_desc: "亲手制作盲文名字的体验",
            booth4_title: "轮椅驾照考试",
            booth4_desc: "学习手动轮椅操作并通过障碍物",
            booth5_title: "盲杖行走体验",
            booth5_desc: "佩戴眼罩并使用盲杖行走",
            booth6_title: "学习基础手语及问候",
            booth6_desc: "学习简单的手语单词和问候语",
            booth7_title: "无障碍电影宣传",
            booth7_desc: "画面解说及字幕电影制作过程介绍",
            booth8_title: "残疾人辅助器具展示",
            booth8_desc: "体验最新的信息通信辅助器具及生活辅助工具",
            booth9_title: "残疾人体育体验 (地板滚球)",
            booth9_desc: "残奥会正式项目地板滚球体验",
            booth10_title: "残疾人体育体验 (篮球)",
            booth10_desc: "轮椅篮球投篮体验及规则说明",
            booth11_title: "残疾人产品'Dreamdra'市场",
            booth11_desc: "重度残疾人生产的产品展示与销售",
            booth12_title: "残疾人就业咨询",
            booth12_desc: "就业支持及职业培训计划指南",
            booth13_title: "发育障碍艺术家展览",
            booth13_desc: "欣赏发育障碍作家独具匠心的美术作品",
            booth14_title: "残疾人权益维护咨询",
            booth14_desc: "预防侵犯人权及法律咨询支持",
            booth15_title: "残疾意识改善OX测验",
            booth15_desc: "通过测验了解关于残疾的正确常识",
            booth16_title: "学习手语歌曲",
            booth16_desc: "用手语表达优美的歌词",
            booth17_title: "盲文图书及触觉体验",
            booth17_desc: "阅读盲文图书及触觉教具体验",
            booth18_title: "残疾人家庭支持指南",
            booth18_desc: "为残疾人家庭提供的休息及咨询计划",
            booth19_title: "残疾人活动支持咨询",
            booth19_desc: "活动支持服务申请及使用方法指南",
            booth20_title: "残疾人福利待遇指南",
            booth20_desc: "关于养老金、津贴及各种减免优惠的信息",
            booth21_title: "辅助器具维修中心",
            booth21_desc: "轮椅及辅助器具免费检查与维修",
            booth22_title: "残疾人文化艺术 (陶艺)",
            booth22_desc: "指尖捏合的陶瓷制作体验",
            booth23_title: "残疾人文化艺术 (园艺)",
            booth23_desc: "利用花卉和植物的治愈园艺体验",
            booth24_title: "残疾人信息化教育指南",
            booth24_desc: "智能手机及电脑使用教育计划介绍",
            booth25_title: "残疾人人权电影节宣传",
            booth25_desc: "电影上映日程及参与指南",
            booth26_title: "残疾人自立生活指南",
            booth26_desc: "自立生活住房及支持服务介绍",
            booth27_title: "便利设施监测宣传",
            booth27_desc: "为建设无障碍城市的便利设施检查活动",
            booth28_title: "残疾人终身教育指南",
            booth28_desc: "为成年残疾人提供的终身学习计划介绍",
            booth29_title: "残疾人体育协会宣传",
            booth29_desc: "地区残疾人体育俱乐部及加入指南",
            booth30_title: "满意度调查及意见箱",
            booth30_desc: "留下参与感言及改进意见",
            performance_tag: "演出",
            performance_title: "演出时间表",
            performance_tab: "4.25(周六)",
            scroll_hint: "向侧面滑动查看",
            scroll_hint_text: "左右滚动",
            perf_table_time: "时间",
            perf_table_title: "演出名称",
            perf_table_artist: "演职人员",
            parking_tag: "停车",
            parking_title: "停车指南",
            parking_card1_title: "附近停车场",
            parking_loc1: "1. 美观广场",
            parking_loc2: "2. 始兴市南部老人福利馆",
            parking_loc3: "3. 相生停车商城",
            parking_btn_map: "确认地点",
            parking_notice: "预计活动当天交通拥挤，建议使用公共交通。",
            parking_card2_title: "公共交通指南",
            parking_bus_info: "在正往站（4号线）或附近的易买得公交站下车后步行",
            parking_bus_sub: "请前往正往洞美观广场3号。",
            accessibility_tag: "移动便利",
            accessibility_title: "移动便利服务",
            accessibility_notice: "美观广场的移动便利班车乘车点位于标有轮椅图标的车站。请在出发前10分钟到达。",
            acc_table_round: "车次",
            acc_table_loc1: "美观广场3号 (会场)",
            acc_table_loc2: "长岘 19园区 正门",
            acc_table_loc3: "牧甘 7园区 正门",
            acc_table_loc4: "能谷小学 对面",
            acc_table_loc5: "始兴市政厅 正门对面",
            acc_table_loc6: "美观广场3号 (会场)",
            inquiry_tag: "咨询/意见",
            inquiry_title: "咨询及意见",
            inquiry_form_title: "发送咨询及活动意见",
            inquiry_label_name: "姓名",
            inquiry_placeholder_name: "请输入姓名",
            inquiry_label_email: "联系方式/邮箱",
            inquiry_placeholder_email: "请输入回复联系方式",
            inquiry_label_message: "咨询及意见内容",
            inquiry_placeholder_message: "请输入咨询内容或对活动的意见",
            inquiry_btn_submit: "发送意见",
            success_title: "提交完成",
            success_message: "感谢您的宝贵意见。",
            footer_host_label: "主办：",
            footer_host_name: "始兴残疾人综合福利馆",
            footer_organizer_label: "承办：",
            footer_organizer_name: "始兴残疾人综合福利馆、咸岘相生综合社会福利馆、始兴市终身学习社团联合会、始兴市大也综合社会福利馆、始兴市正往综合社会福利馆、始兴市残疾人家庭支持中心、始兴市南部老人福利馆",
            footer_contact_label: "咨询：",
            sending: "发送中...",
            submit_error: "提交过程中发生错误，请稍后重试。",
            network_error: "发生网络错误。"
        },
        vi: {
            festival_name: "Lễ hội Không rào cản lần thứ 4 - Cùng xem, Thấy giá trị",
            logo_line1: "Không ai bị bỏ lại phía sau",
            logo_line2: "Lễ hội Không rào cản",
            nav_home: "Trang chủ",
            nav_programs: "Gian hàng trải nghiệm",
            nav_performance: "Lịch biểu diễn",
            nav_parking: "Hướng dẫn đỗ xe",
            nav_accessibility: "Hỗ trợ di chuyển",
            nav_inquiry: "Liên hệ/Ý kiến",
            hero_subtitle_top: "Lễ hội Không rào cản lần thứ 4",
            hero_title: "Lễ hội Không rào cản",
            hero_date: "2026. 04. 25(Thứ Bảy) 11:00 ~ 16:00",
            hero_venue: "Quảng trường Migwan số 3, Jeongwang-dong",
            hero_btn_map: "Xem địa điểm tổ chức",
            hero_btn_booths: "Hướng dẫn gian hàng",
            hero_btn_performance: "Lịch biểu diễn",
            about_tag: "GIỚI THIỆU",
            about_title: "Lễ hội cùng xem và chia sẻ giá trị",
            about_item1_title: "Cùng xem:",
            about_item1_desc: "Lễ hội hạnh phúc cho cả người khuyết tật và người không khuyết tật",
            about_item2_title: "Thấy giá trị:",
            about_item2_desc: "Một xã hội nhìn thấy giá trị của sự đa dạng",
            about_main_desc: "Lễ hội này nhằm tạo ra một không gian giao lưu giữa người khuyết tật và người không khuyết tật, cải thiện nhận thức xã hội thông qua các trải nghiệm thực tế và thúc đẩy quyền lợi của người khuyết tật.",
            image_caption: "<Lễ hội Cùng xem, Thấy giá trị lần thứ 2 năm 2024>",
            experience_tag: "TRẢI NGHIỆM",
            experience_title: "Hướng dẫn gian hàng trải nghiệm",
            booth1_title: "Ban điều hành & Quầy thông tin",
            booth1_desc: "Hướng dẫn lễ hội, bảo vệ trẻ lạc, tiếp nhận đồ thất lạc",
            booth2_title: "Nhận quà lưu niệm & Bốc thăm trúng thưởng",
            booth2_desc: "Nhận quà sau khi hoàn thành stamp tour",
            booth3_title: "Trải nghiệm làm danh thiếp chữ nổi",
            booth3_desc: "Tự tay in tên mình bằng chữ nổi Braille",
            booth4_title: "Thi bằng lái xe lăn",
            booth4_desc: "Học cách điều khiển xe lăn tay và vượt chướng ngại vật",
            booth5_title: "Trải nghiệm đi bộ với gậy trắng",
            booth5_desc: "Đeo băng bịt mắt và di chuyển bằng gậy trắng",
            booth6_title: "Học ngôn ngữ ký hiệu cơ bản",
            booth6_desc: "Học các từ vựng và lời chào đơn giản bằng ký hiệu",
            booth7_title: "Quảng bá phim không rào cản",
            booth7_desc: "Giới thiệu quy trình sản xuất phim có thuyết minh và phụ đề",
            booth8_title: "Trưng bày thiết bị hỗ trợ người khuyết tật",
            booth8_desc: "Trải nghiệm các thiết bị CNTT và đồ dùng hỗ trợ đời sống mới nhất",
            booth9_title: "Trải nghiệm thể thao (Boccia)",
            booth9_desc: "Trải nghiệm môn Boccia - môn thể thao chính thức của Paralympic",
            booth10_title: "Trải nghiệm thể thao (Bóng rổ)",
            booth10_desc: "Trải nghiệm ném bóng rổ trên xe lăn và hướng dẫn luật chơi",
            booth11_title: "Chợ sản phẩm 'Dreamdra' của người khuyết tật",
            booth11_desc: "Trưng bày và bán các sản phẩm do người khuyết tật nặng sản xuất",
            booth12_title: "Tư vấn việc làm cho người khuyết tật",
            booth12_desc: "Hỗ trợ tìm việc và hướng dẫn các chương trình đào tạo nghề",
            booth13_title: "Triển lãm nghệ sĩ khuyết tật phát triển",
            booth13_desc: "Thưởng thức các tác phẩm mỹ thuật độc đáo của các họa sĩ khuyết tật",
            booth14_title: "Tư vấn bảo vệ quyền lợi người khuyết tật",
            booth14_desc: "Phòng ngừa vi phạm nhân quyền và hỗ trợ tư vấn pháp lý",
            booth15_title: "Đố vui OX cải thiện nhận thức về khuyết tật",
            booth15_desc: "Giải đáp các kiến thức đúng về khuyết tật qua trò chơi đố vui",
            booth16_title: "Học hát bằng ngôn ngữ ký hiệu",
            booth16_desc: "Thể hiện lời bài hát ý nghĩa bằng ngôn ngữ ký hiệu",
            booth17_title: "Sách chữ nổi & Trải nghiệm xúc giác",
            booth17_desc: "Đọc sách chữ nổi và trải nghiệm giáo cụ xúc giác",
            booth18_title: "Hướng dẫn hỗ trợ gia đình người khuyết tật",
            booth18_desc: "Các chương trình nghỉ ngơi và tư vấn cho gia đình người khuyết tật",
            booth19_title: "Tư vấn hỗ trợ hoạt động người khuyết tật",
            booth19_desc: "Hướng dẫn đăng ký và sử dụng dịch vụ hỗ trợ hoạt động",
            booth20_title: "Hướng dẫn quyền lợi phúc lợi người khuyết tật",
            booth20_desc: "Thông tin về lương hưu, phụ cấp và các ưu đãi giảm miễn",
            booth21_title: "Trung tâm sửa chữa thiết bị hỗ trợ",
            booth21_desc: "Kiểm tra và sửa chữa miễn phí xe lăn và thiết bị hỗ trợ",
            booth22_title: "Văn hóa nghệ thuật (Gốm sứ)",
            booth22_desc: "Trải nghiệm làm gốm bằng đôi bàn tay",
            booth23_title: "Văn hóa nghệ thuật (Làm vườn)",
            booth23_desc: "Trải nghiệm làm vườn trị liệu với hoa và cây cảnh",
            booth24_title: "Hướng dẫn đào tạo CNTT cho người khuyết tật",
            booth24_desc: "Giới thiệu các chương trình đào tạo sử dụng smartphone và PC",
            booth25_title: "Quảng bá liên hoan phim nhân quyền người khuyết tật",
            booth25_desc: "Lịch chiếu phim và hướng dẫn tham gia",
            booth26_title: "Hướng dẫn sống tự lập cho người khuyết tật",
            booth26_desc: "Giới thiệu nhà ở tự lập và các dịch vụ hỗ trợ tự lập",
            booth27_title: "Quảng bá giám sát cơ sở hạ tầng tiện ích",
            booth27_desc: "Các hoạt động kiểm tra tiện ích vì một thành phố không rào cản",
            booth28_title: "Hướng dẫn giáo dục trọn đời cho người khuyết tật",
            booth28_desc: "Giới thiệu các chương trình học tập trọn đời cho người khuyết tật trưởng thành",
            booth29_title: "Quảng bá hiệp hội thể thao người khuyết tật",
            booth29_desc: "Hướng dẫn các câu lạc bộ thể thao địa phương và cách gia nhập",
            booth30_title: "Khảo sát mức độ hài lòng & Hòm thư góp ý",
            booth30_desc: "Để lại cảm nhận tham gia và ý kiến cải thiện",
            performance_tag: "BIỂU DIỄN",
            performance_title: "Lịch biểu diễn",
            performance_tab: "25.04(Thứ Bảy)",
            scroll_hint: "Vuốt sang bên để xem",
            scroll_hint_text: "Cuộn trái/phải",
            perf_table_time: "Thời gian",
            perf_table_title: "Tên buổi diễn",
            perf_table_artist: "Nghệ sĩ",
            parking_tag: "ĐỖ XE",
            parking_title: "Hướng dẫn đỗ xe",
            parking_card1_title: "Bãi đỗ xe gần đây",
            parking_loc1: "1. Quảng trường Migwan",
            parking_loc2: "2. Trung tâm phúc lợi người cao tuổi phía Nam Siheung",
            parking_loc3: "3. Trung tâm đỗ xe Sangsaeng",
            parking_btn_map: "Xem bản đồ",
            parking_notice: "Dự kiến sẽ rất đông đúc vào ngày diễn ra sự kiện. Khuyến khích sử dụng phương tiện công cộng.",
            parking_card2_title: "Phương tiện công cộng",
            parking_bus_info: "Xuống tại ga Jeongwang (Tuyến số 4) hoặc trạm xe buýt E-Mart gần đó",
            parking_bus_sub: "Vui lòng đến Quảng trường Migwan số 3, Jeongwang-dong.",
            accessibility_tag: "HỖ TRỢ DI CHUYỂN",
            accessibility_title: "Dịch vụ hỗ trợ di chuyển",
            accessibility_notice: "Điểm đón xe buýt hỗ trợ di chuyển tại Quảng trường Migwan nằm ở trạm có biểu tượng xe lăn. Vui lòng đến trước giờ khởi hành 10 phút.",
            acc_table_round: "Chuyến",
            acc_table_loc1: "Quảng trường Migwan 3 (Sự kiện)",
            acc_table_loc2: "Cổng chính Khu 19 Janghyeon",
            acc_table_loc3: "Cổng chính Khu 7 Mokgam",
            acc_table_loc4: "Đối diện Tiểu học Neunggok",
            acc_table_loc5: "Đối diện cổng chính UBND Siheung",
            acc_table_loc6: "Quảng trường Migwan 3 (Sự kiện)",
            inquiry_tag: "LIÊN HỆ/Ý KIẾN",
            inquiry_title: "Liên hệ và Ý kiến",
            inquiry_form_title: "Gửi liên hệ và ý kiến về sự kiện",
            inquiry_label_name: "Họ tên",
            inquiry_placeholder_name: "Vui lòng nhập họ tên",
            inquiry_label_email: "Liên hệ/Email",
            inquiry_placeholder_email: "Nhập thông tin liên hệ để nhận phản hồi",
            inquiry_label_message: "Nội dung liên hệ/ý kiến",
            inquiry_placeholder_message: "Nhập nội dung liên hệ hoặc ý kiến về lễ hội",
            inquiry_btn_submit: "Gửi ý kiến",
            success_title: "Đã gửi thành công",
            success_message: "Cảm ơn ý kiến quý báu của bạn.",
            footer_host_label: "Chủ trì:",
            footer_host_name: "Trung tâm Phúc lợi Người khuyết tật Tổng hợp Siheung",
            footer_organizer_label: "Tổ chức:",
            footer_organizer_name: "Trung tâm Phúc lợi Người khuyết tật Tổng hợp Siheung, Trung tâm Phúc lợi Xã hội Tổng hợp Hamhyeon Sangsaeng, Liên hiệp Câu lạc bộ Học tập Trọn đời TP Siheung, Trung tâm Phúc lợi Xã hội Tổng hợp Daeya TP Siheung, Trung tâm Phúc lợi Xã hội Tổng hợp Jeongwang TP Siheung, Trung tâm Hỗ trợ Gia đình Người khuyết tật TP Siheung, Trung tâm Phúc lợi Người cao tuổi phía Nam TP Siheung",
            footer_contact_label: "Liên hệ:",
            sending: "Đang gửi...",
            submit_error: "Đã xảy ra lỗi khi gửi. Vui lòng thử lại.",
            network_error: "Đã xảy ra lỗi mạng."
        }
    };

    let currentLang = localStorage.getItem('selected-lang') || 'ko';

    function updateLanguage(lang) {
        currentLang = lang;
        localStorage.setItem('selected-lang', lang);
        
        // Update regular text elements
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            if (translations[lang][key]) {
                el.innerText = translations[lang][key];
            }
        });

        // Update placeholders
        document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
            const key = el.getAttribute('data-i18n-placeholder');
            if (translations[lang][key]) {
                el.setAttribute('placeholder', translations[lang][key]);
            }
        });

        // Update current language display
        const langDisplay = document.getElementById('current-lang');
        const langNames = { ko: 'KR', en: 'EN', zh: 'CN', vi: 'VN' };
        if (langDisplay) langDisplay.innerText = langNames[lang];

        // Update active class in dropdown
        document.querySelectorAll('.lang-option').forEach(opt => {
            const langCode = opt.getAttribute('data-lang');
            opt.innerText = langNames[langCode];
            opt.classList.toggle('active', langCode === lang);
        });

        // Update schedule if it's loaded
        updateSchedule('0425');
    }

    // Language Switcher Logic
    const langBtn = document.getElementById('lang-btn');
    const langDropdown = document.getElementById('lang-dropdown');
    
    if (langBtn && langDropdown) {
        langBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            langDropdown.classList.toggle('active');
        });

        document.querySelectorAll('.lang-option').forEach(opt => {
            opt.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                const lang = opt.getAttribute('data-lang');
                updateLanguage(lang);
                langDropdown.classList.remove('active');
            });
        });

        document.addEventListener('click', () => {
            langDropdown.classList.remove('active');
        });
    }

    // Header Scroll Effect
    const header = document.getElementById('header');
    if (header) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }

    // Accessibility: High Contrast Toggle
    const contrastToggle = document.getElementById('contrast-toggle');
    if (contrastToggle) {
        contrastToggle.addEventListener('click', (e) => {
            e.preventDefault();
            document.body.classList.toggle('high-contrast');
            const isHighContrast = document.body.classList.contains('high-contrast');
            localStorage.setItem('high-contrast', isHighContrast);
        });
    }

    // Check saved preference
    if (localStorage.getItem('high-contrast') === 'true') {
        document.body.classList.add('high-contrast');
    }

    // Accessibility: Font Size Adjustment
    const fontSizeBtn = document.getElementById('font-size-up');
    if (fontSizeBtn) {
        let fontSizeLevel = 0;
        const maxLevel = 3;
        
        fontSizeBtn.addEventListener('click', (e) => {
            e.preventDefault();
            fontSizeLevel = (fontSizeLevel + 1) % (maxLevel + 1);
            const baseSize = 16;
            const newSize = baseSize + (fontSizeLevel * 2);
            document.documentElement.style.fontSize = `${newSize}px`;
            
            // Update icon or feedback
            if (fontSizeLevel === 0) {
                fontSizeBtn.innerHTML = '<i data-lucide="zoom-in"></i>';
            } else {
                fontSizeBtn.innerHTML = `<span>+${fontSizeLevel}</span>`;
            }
            if (window.lucide) {
                window.lucide.createIcons();
            }
        });
    }

    // Performance Schedule Data
    const scheduleData = {
        '0425': [
            { 
                time: '11:00', 
                title: { ko: '개막 축하 공연', en: 'Opening Celebration', zh: '开幕祝贺演出', vi: 'Biểu diễn chúc mừng khai mạc' }, 
                note: { ko: '가치봄 합창단', en: 'Value See Choir', zh: '价值见合唱团', vi: 'Dàn hợp xướng Thấy giá trị' } 
            },
            { 
                time: '12:30', 
                title: { ko: '수어 뮤지컬: 봄의 소리', en: 'Sign Language Musical: Sound of Spring', zh: '手语音乐剧：春之声', vi: 'Nhạc kịch ký hiệu: Âm thanh mùa xuân' }, 
                note: { ko: '극단 손짓', en: 'Theater Sonjit', zh: '手势剧团', vi: 'Đoàn kịch Sonjit' } 
            },
            { 
                time: '14:00', 
                title: { ko: '배리어프리 버스킹', en: 'Barrier-free Busking', zh: '无障碍街头表演', vi: 'Hát rong không rào cản' }, 
                note: { ko: '로컬 아티스트', en: 'Local Artists', zh: '当地艺术家', vi: 'Nghệ sĩ địa phương' } 
            },
            { 
                time: '15:30', 
                title: { ko: '폐막 퍼포먼스', en: 'Closing Performance', zh: '闭幕表演', vi: 'Biểu diễn bế mạc' }, 
                note: { ko: '전 출연진', en: 'All Performers', zh: '全体演职人员', vi: 'Toàn bộ diễn viên' } 
            }
        ]
    };

    const scheduleBody = document.getElementById('schedule-body');
    const tabBtns = document.querySelectorAll('.tab-btn');

    function updateSchedule(date) {
        const scheduleBody = document.getElementById('schedule-body');
        if (!scheduleBody) return;
        
        const data = scheduleData[date];
        if (!data) return;
        
        scheduleBody.innerHTML = '';
        
        data.forEach(item => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${item.time}</td>
                <td><strong>${item.title[currentLang] || item.title.ko}</strong></td>
                <td>${item.note[currentLang] || item.note.ko}</td>
            `;
            scheduleBody.appendChild(row);
        });
    }

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            tabBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            updateSchedule(btn.dataset.date);
        });
    });

    // Initial load
    updateLanguage(currentLang);
    
    // Ensure schedule is loaded after DOM is fully ready and elements are found
    setTimeout(() => {
        updateSchedule('0425');
    }, 0);

    // Mobile Menu Logic
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navOverlay = document.querySelector('.nav-overlay');
    const backdrop = document.querySelector('.overlay-backdrop');
    const navLinks = document.querySelectorAll('.nav-overlay .nav-links a');

    function toggleMenu() {
        navOverlay.classList.toggle('active');
        backdrop.classList.toggle('active');
        
        const isOpen = navOverlay.classList.contains('active');
        mobileMenuBtn.innerHTML = isOpen ? '<i data-lucide="x"></i>' : '<i data-lucide="menu"></i>';
        lucide.createIcons();
    }

    mobileMenuBtn.addEventListener('click', toggleMenu);
    backdrop.addEventListener('click', toggleMenu);
    navLinks.forEach(link => {
        link.addEventListener('click', toggleMenu);
    });

    // Inquiry Form AJAX Submission
    const inquiryForm = document.getElementById('inquiry-form');
    const successModal = document.getElementById('success-modal');
    const closeModal = document.querySelector('.close-modal');

    if (inquiryForm && successModal) {
        inquiryForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(inquiryForm);
            const submitBtn = inquiryForm.querySelector('button[type="submit"]');
            const originalBtnText = submitBtn.innerText;
            
            submitBtn.disabled = true;
            submitBtn.innerText = translations[currentLang].sending;
            
            try {
                const response = await fetch(inquiryForm.action, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'Accept': 'application/json'
                    }
                });
                
                if (response.ok) {
                    successModal.classList.add('active');
                    inquiryForm.reset();
                } else {
                    alert(translations[currentLang].submit_error);
                }
            } catch (error) {
                console.error('Submission error:', error);
                alert(translations[currentLang].network_error);
            } finally {
                submitBtn.disabled = false;
                submitBtn.innerText = originalBtnText;
            }
        });

        closeModal.addEventListener('click', () => {
            successModal.classList.remove('active');
        });

        // Close modal when clicking outside content
        window.addEventListener('click', (e) => {
            if (e.target === successModal) {
                successModal.classList.remove('active');
            }
        });
    }

    // Scroll Hint Logic
    function setupScrollHint(wrapperId, overlayId) {
        const wrapper = document.getElementById(wrapperId);
        const overlay = document.getElementById(overlayId);
        
        if (wrapper && overlay) {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        overlay.classList.add('active');
                        setTimeout(() => {
                            overlay.classList.remove('active');
                        }, 2000);
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.2 });
            
            observer.observe(wrapper);
        }
    }

    setupScrollHint('shuttle-wrapper', 'scroll-hint-overlay');
    setupScrollHint('parking-wrapper', 'parking-scroll-hint');
    setupScrollHint('performance-wrapper', 'performance-scroll-hint');
});
